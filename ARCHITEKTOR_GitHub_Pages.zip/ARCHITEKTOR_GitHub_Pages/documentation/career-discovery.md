# Career discovery update

Primary journey: upload/paste CV with no target role or vacancy required; identify documented experience, suggest plausible near, adjacent and stretch role hypotheses, show exact source evidence, unknowns, a small experiment, and 30/60/90-day milestones. User interests, values and practical constraints are optional explicit self-reports; do not infer desired career or personality from CV. Vacancy tailoring remains a secondary action after choosing a direction.

Keep local rules clearly separate from a model-backed review. Rank options as exploration hypotheses rather than hiring probabilities. Retain source language in quotes and support English, Ukrainian, Russian and Hebrew. Do not administer an altered standardized questionnaire or imply psychometric/clinical validation. Reference O*NET career exploration, IPIP usage/translation limits and SIOP assessment validation guidance.

Verification: synthetic scenario tests for evidence/negation/injection/unknowns, source validation, experiment capacity and all report languages; TypeScript and production build; browser CV-only sample, source/roadmap views, refinement and secondary vacancy flow. Live model testing requires configured credentials.
