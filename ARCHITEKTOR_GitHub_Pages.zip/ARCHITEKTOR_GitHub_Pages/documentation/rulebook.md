# ARCHITEKTOR rulebook 1.0

All new reviews execute in the browser. No model, API key, paid inference or remote analysis is used. The former remote endpoint returns HTTP 410 even if credentials exist.

## Discovery

1. Read supplied CV text; isolate instruction-like text and separate negated clauses, contradictions, learning context and another person's contribution.
2. Match multilingual aliases with word boundaries against the catalog in `lib/discovery.mjs`. Repeated occurrences of the same skill do not add points.
3. Require at least one positive core signal to propose a catalog direction. The catalog covers software, QA, cloud, DevOps, data, project coordination, security operations, GRC and support. Unsupported CVs receive neutral exploration questions; they are not forced into IT.
4. Sort by 8 points for explicitly current support employment + 3 per core signal with action evidence + 1 per positive core signal + 0.1 per related signal. The support title bonus is a narrow implemented rule, not a general current-title parser. Stable catalog order breaks ties. Retain at most three directions.
5. Report action evidence for at least two core signals as supported, one as developing, otherwise limited. Near means current support employment or supported evidence; adjacent means developing; stretch means limited. These editorial thresholds have not been calibrated against hiring outcomes.
6. Show the exact source quotes, score contributions, uncertainty, other catalog signals to investigate, a small task experiment and 30/60/90-day review milestones. A skill catalog is not a mandatory checklist for every vacancy.
7. Keep interests, values and constraints as explicit self-report. Free-text preferences do not affect ranking. Ask up to three unanswered preference questions, then request contribution examples and experiment feedback. No personality, mental-health or psychological diagnosis is inferred.

## Vacancy comparison (secondary)

Required requirement weight = 2; preferred = 1. Direct evidence earns full weight, transferable evidence half, unknown/missing/contradicted zero. Missing wording is unknown, not proof of a deficiency. OR branches are alternatives. Coverage is document evidence coverage, not an employer ATS score or hiring probability.

## Boundaries

Rules use text patterns, not unrestricted semantic understanding. Personal contribution and proficiency still need confirmation. Market demand, compensation and role availability are not estimated. Saved cases are browser-local and exports are user-triggered. Reports preserve separate English, Ukrainian, Russian and Hebrew narrative variants; the UI and audit labels are currently English.
