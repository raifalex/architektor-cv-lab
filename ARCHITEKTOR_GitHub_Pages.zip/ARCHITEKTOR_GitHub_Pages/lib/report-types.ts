export type Language = "en" | "uk" | "ru" | "he";
export type ReviewInput = { cv: string; jd: string; role: string; market: string; language: Language; minutes: number; mode: "discovery" | "targeted" | "baseline"; seniority?: string; caseName?: string; preferences?: { interests: string; values: string; constraints: string } };
export type EvidenceStatus = "direct" | "transferable" | "unknown" | "missing" | "contradicted";
export type Requirement = { id: string; text: string; importance: "must" | "preferred"; status: EvidenceStatus; source: string; evidence: string[]; explanation: string; names?: string[] };
export type ReviewReport = {
 id: string; created: string; source: "local" | "ai"; role: string; market: string; language: Language;
 coverage: number | null; points: number; maxPoints: number;
 counts: Record<EvidenceStatus, number>; summary: string; requirements: Requirement[];
 strengths: { title: string; detail: string; evidence: string[] }[];
 findings: { level: string; title: string; detail: string }[];
 rewrites: { before: string; after: string; why: string; evidence: string[] }[];
 plan: { week: number; title: string; task: string; minutes: number }[];
 questions: string[]; limitations: string[]; ignoredInstructions: number; discovery?: CareerDiscovery | null;
};
export type SavedCase = { id: string; name: string; savedAt: string; input: ReviewInput; report: ReviewReport };


export type CareerDiscovery = {
 profile: { headline: string; summary: string; evidence: string[]; unknowns: string[] };
 paths: CareerPath[];
 workStyle: { summary: string; observations: { topic: "interests" | "values" | "constraints"; statement: string; quote: string }[]; unknowns: string[] };
 questions: string[]; method: string;
};
export type CareerPath = {
 ruleTrace?: { version: string; rankPoints: number; currentRolePoints: number; actionSkills: string[]; actionPoints: number; coreSkills: string[]; corePoints: number; relatedSkills: string[]; relatedPoints: number; unobservedSkills: string[] };
 id: string; role: string; horizon: "near" | "adjacent" | "stretch";
 rationale: string; evidence: string[]; transferable: string[]; unknowns: string[];
 evidenceStrength: "limited" | "developing" | "supported";
 experiment: { task: string; success: string; minutes: number };
 milestones: { day: number; task: string; success: string }[];
};
