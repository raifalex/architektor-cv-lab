import type { ReviewInput, CareerDiscovery } from "./report-types";

/** Deterministic local hypotheses based on CV quotations, with separate self-reported preferences. */
export function discoverCareers(input: ReviewInput): CareerDiscovery;
export function validateDiscovery(discovery: unknown, input: ReviewInput): string[];
