import pdfWorkerUrl from "pdfjs-dist/build/pdf.worker.min.mjs?url";

export async function readDocument(file: File): Promise<{ text: string; warnings: string[] }> {
 if (file.size > 10 * 1024 * 1024) throw new Error("Choose a file smaller than 10 MB.");
 const ext=file.name.toLowerCase().split(".").pop();
 if(ext==="txt"||ext==="md")return {text:await file.text(),warnings:[]};
 if(ext==="docx"){
  const mammoth=await import("mammoth/mammoth.browser.js");
  const result=await mammoth.extractRawText({arrayBuffer:await file.arrayBuffer()});
  if(!result.value.trim())throw new Error("No readable text found. Paste your CV instead.");
  return {text:result.value,warnings:result.messages.map((m:{message:string})=>m.message)};
 }
 if(ext==="pdf"){
  const pdfjs=await import("pdfjs-dist");
  pdfjs.GlobalWorkerOptions.workerSrc=pdfWorkerUrl;
  const task=pdfjs.getDocument({data:await file.arrayBuffer(),useSystemFonts:true});
  const pdf=await task.promise;
  if(pdf.numPages>30){await task.destroy();throw new Error("Please use a CV of 30 pages or fewer.");}
  const pages:string[]=[];
  try{
   for(let n=1;n<=pdf.numPages;n++){
    const page=await pdf.getPage(n);const content=await page.getTextContent();
    const text=content.items.map(item=>"str" in item?item.str+(item.hasEOL?"\n":" "):"").join("");
    if(!text.trim())throw new Error("Page "+n+" has no readable text. Upload a text-based PDF or paste the full CV.");
    pages.push(text);
   }
  }finally{await task.destroy();}
  return {text:pages.join("\n\n"),warnings:["Check the extracted text below before reviewing. PDF reading order may differ from the page layout."]};
 }
 throw new Error("Please choose a PDF, DOCX, TXT, or Markdown file.");
}

