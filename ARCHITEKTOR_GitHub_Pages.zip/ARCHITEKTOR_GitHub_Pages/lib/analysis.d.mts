import type { ReviewInput, ReviewReport, Requirement } from "./report-types";
export function analyze(input: ReviewInput): ReviewReport;
export function contains(text: string, name: string): boolean;
export function extractRequirements(jd: string): Requirement[];
export function validateAIReport(report: unknown, input: ReviewInput): string[];
export function reportMarkdown(report: ReviewReport): string;
export const SKILLS: [string, string[]][];

