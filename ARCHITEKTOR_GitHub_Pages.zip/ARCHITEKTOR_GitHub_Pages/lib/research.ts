export const repositories = [
  {
    "repo": "Dannyvice/evidence-first-resume-skill",
    "title": "Evidence-First Resume",
    "license": "MIT",
    "decision": "Installed as the CV evidence and tailoring foundation.",
    "text": "The clearest match for a trustworthy CV analyzer. It separates source facts from vacancy requirements, asks focused questions, preserves contribution level, and requires document QA. It explicitly avoids invented experience and ATS pass probabilities. Small community size is a maintenance uncertainty, not a reason to replace stronger methodology with a popular but weaker prompt.",
    "url": "https://github.com/Dannyvice/evidence-first-resume-skill",
    "category": "foundation"
  },
  {
    "repo": "Jeff-Kazzee/career-coach",
    "title": "Career Coach",
    "license": "MIT",
    "decision": "Installed as the coaching layer.",
    "text": "Provides career intake, funnel diagnosis, proof-gap analysis, interview preparation, and recurring evidence reviews. It distinguishes skills, positioning, execution, and market constraints instead of prescribing more applications to everyone. Includes an offline scorecard and tests. The installed copy adds no-clobber output protection to the optional scorecard; the regression test and original MIT notice are retained.",
    "url": "https://github.com/Jeff-Kazzee/career-coach",
    "category": "foundation"
  },
  {
    "repo": "Remotivated/job-hunt-skills",
    "title": "Job Hunt Skills",
    "license": "MIT",
    "decision": "Best next addition for a dedicated claims audit.",
    "text": "The inspected resume-auditor and claim-check workflows are useful because they tie rewrites to source evidence, distinguish unsupported claims by severity, and handle retracted statements. This is a larger plugin with shared truth rules and document conventions; copying one SKILL.md would omit dependencies. It was reviewed as a future integration, not installed in this first stack.",
    "url": "https://github.com/Remotivated/job-hunt-skills",
    "category": "reference"
  },
  {
    "repo": "Paramchoudhary/ResumeSkills",
    "title": "ResumeSkills",
    "license": "MIT",
    "decision": "Strong reference library; adapt selected modules.",
    "text": "The collection has 22 main skills spanning bullets, tailoring, technical resumes, career changes, interviews, and negotiation. Five relevant skill files were inspected. Useful writing patterns coexist with keyword-match percentages, numerical estimates, and a bullet rule favoring a number in every bullet. For ARCHITEKTOR, remove mandatory numbers, keep estimates out of factual claims, and label any coverage arithmetic precisely.",
    "url": "https://github.com/Paramchoudhary/ResumeSkills",
    "category": "reference"
  },
  {
    "repo": "varunr89/resume-tailoring-skill",
    "title": "Resume Tailoring Skill",
    "license": "MIT",
    "decision": "Useful for guided achievement discovery.",
    "text": "Researches a target role, interviews the candidate about undocumented experience, and builds tailored material from a resume library. A good model for evidence discovery and reusable profiles. Its platform-specific tool assumptions and any confidence percentages need adaptation before use as a neutral multi-client service.",
    "url": "https://github.com/varunr89/resume-tailoring-skill",
    "category": "reference"
  },
  {
    "repo": "jain777/jobclaw-skills",
    "title": "JobClaw Skills",
    "license": "MIT",
    "decision": "Useful reference for a broader career operating system.",
    "text": "Twenty skills share a master profile, region conventions, and artifact sidecars. The inspected fit and tailoring workflows preserve truthfulness and handle OR requirements. Their cross-skill dependencies matter. The numeric-bullet quota and ATS-style scores need revision. Application, inbox, and outreach automation extend beyond the requested CV-review workflow.",
    "url": "https://github.com/jain777/jobclaw-skills",
    "category": "reference"
  },
  {
    "repo": "jirawatp/resume-career-toolkit",
    "title": "Resume Career Toolkit",
    "license": "MIT",
    "decision": "Compact alternative writing reference.",
    "text": "Twenty skills cover parsing checks, bullet rewriting, customization, role sections, interviews, and career pivots. The ATS checker is useful for separating file, structure, and terminology issues. Treat these as playbooks rather than evidence of real employer-system performance; it is a small project with limited visible adoption.",
    "url": "https://github.com/jirawatp/resume-career-toolkit",
    "category": "reference"
  },
  {
    "repo": "dabydat/resume-builder-skill",
    "title": "Resume Builder Skill",
    "license": "MIT",
    "decision": "Useful for document structure and bullet patterns.",
    "text": "Ships a writing workflow and supporting guidance influenced by university and engineering-resume practices. Helpful for building clean documents. English and Spanish guidance does not establish Ukrainian, Russian, or Hebrew output quality. Marketing references to a large online community are not validation of this particular skill.",
    "url": "https://github.com/dabydat/resume-builder-skill",
    "category": "reference"
  },
  {
    "repo": "max-favilli/ai-career-coach",
    "title": "AI Career Coach",
    "license": "MIT",
    "decision": "Good profile-encyclopedia and gap-interview ideas.",
    "text": "Its JD workflow checks qualifications individually and distinguishes leadership from hands-on work. The persistent profile concept is valuable. However, assigning a midpoint when information is ambiguous can make unknown information look assessed. Replace that behavior with explicit unknowns and avoid subjective culture-fit scoring in a CV review.",
    "url": "https://github.com/max-favilli/ai-career-coach",
    "category": "reference"
  },
  {
    "repo": "TrainWithShubham/skills",
    "title": "TrainWithShubham resume-review",
    "license": "MIT",
    "decision": "Adapt technical prompts; replace the scoring claims.",
    "text": "Strong vocabulary for DevOps, SRE, cloud, and infrastructure reviews. The inspected skill also prescribes a 0-100 ATS score, recruiter rejection labels, PDF-only intake, and broad length rules. These are insufficiently calibrated for a general coaching product. Retain useful technical questions while accepting DOCX/text and contextualizing document length.",
    "url": "https://github.com/TrainWithShubham/skills",
    "category": "reference"
  },
  {
    "repo": "Zal4DW/career-helper",
    "title": "Career Helper",
    "license": "CC BY-NC 4.0",
    "decision": "Exclude from the commercial installation.",
    "text": "A broad, thoughtful collection with application optimization, interviews, skills radar, and career transitions. The actual LICENSE explicitly restricts commercial use. It is therefore excluded from the paid-coaching stack unless separate permission is obtained. GitHub's NOASSERTION label alone would not have revealed the practical restriction.",
    "url": "https://github.com/Zal4DW/career-helper",
    "category": "limited"
  },
  {
    "repo": "Meowdicine/codex-job-search-skills-template",
    "title": "Codex Job Search Skills Template",
    "license": "No explicit license found in inspected tree/README",
    "decision": "Study the pattern; do not vendor by default.",
    "text": "Good early-career configuration, hard-gate checks, truthful tailoring, and staged application conventions. The lack of an explicit reuse license in the inspected materials makes it unsuitable as a copied commercial dependency without clarification. A public repository is not itself a commercial reuse grant.",
    "url": "https://github.com/Meowdicine/codex-job-search-skills-template",
    "category": "limited"
  },
  {
    "repo": "gargraman/claude-resume-builder",
    "title": "Claude Resume Builder",
    "license": "MIT declared in README; no standalone LICENSE found",
    "decision": "Do not use its automatic skill-inference approach.",
    "text": "Combines supplementary sources, gap discovery, and polished tailoring. The inspected workflow permits adjacent-skill inference and generated additions. That can turn plausible capability into a claim the candidate cannot defend. Keep the provenance questions as inspiration, require confirmation of every new skill, and preserve appropriate license notices if later adopted.",
    "url": "https://github.com/gargraman/claude-resume-builder",
    "category": "reference"
  },
  {
    "repo": "vbalashi/master-resume-skill",
    "title": "Master Resume Skill",
    "license": "No explicit license found in inspected tree/README",
    "decision": "Architecture reference pending licensing clarification.",
    "text": "Useful master-profile, raw-versus-reviewed evidence, contribution-level, and visual-QA concepts. It also separates a skill source directory from private candidate workspaces. These are strong design ideas, but licensing needs clarification before copying its implementation into a commercial stack.",
    "url": "https://github.com/vbalashi/master-resume-skill",
    "category": "limited"
  },
  {
    "repo": "donslice/claude-career-coach",
    "title": "Claude Career Coach",
    "license": "No explicit license found in inspected tree/README",
    "decision": "Coaching inspiration pending licensing clarification.",
    "text": "Focuses on excavating real achievements, STAR stories, capability maps, and career narratives. Relevant to clients who undersell their work. The inspected repository lacks an explicit reuse license; its workflow is not installed. It is also a conversation prompt, not a parsing or validation engine.",
    "url": "https://github.com/donslice/claude-career-coach",
    "category": "limited"
  },
  {
    "repo": "proficientlyjobs/proficiently-claude-skills",
    "title": "Proficiently Claude Skills",
    "license": "MIT declared in README; no standalone LICENSE found",
    "decision": "Consider only after reviewing its wider workflow.",
    "text": "Seven skills cover onboarding, job search, tailoring, applications, and networking. The inspected tailoring instructions contain useful restrictions against invented scope and responsibilities. They also impose stylistic rules such as a very high readability target that need language-specific adaptation. It is not selected over the smaller evidence-first foundation.",
    "url": "https://github.com/proficientlyjobs/proficiently-claude-skills",
    "category": "reference"
  },
  {
    "repo": "srbhr/Resume-Matcher",
    "title": "Resume Matcher",
    "license": "Apache-2.0",
    "decision": "Best app-layer candidate for a later integration.",
    "text": "A self-hosted application with FastAPI, Next.js, SQLite, local/remote model options, and an MCP integration. Current README requirements are Python 3.13+ and Node.js 24+ for native setup; Docker is another route. This is an app, not merely an installable career skill. Its README and metadata were reviewed; the application was not deployed or load-tested here.",
    "url": "https://github.com/srbhr/Resume-Matcher",
    "category": "infrastructure"
  },
  {
    "repo": "rendercv/rendercv",
    "title": "RenderCV",
    "license": "MIT",
    "decision": "Optional deterministic document renderer.",
    "text": "Converts structured CV content into rendered artifacts. Useful after claims and wording have been approved. The current README specifies Python 3.12+ and installation with pip install \"rendercv[full]\". Rendering does not evaluate career fit or prove employer ATS compatibility. Ukrainian/Russian font coverage and Hebrew RTL require real output tests before promising support.",
    "url": "https://github.com/rendercv/rendercv",
    "category": "infrastructure"
  },
  {
    "repo": "docling-project/docling",
    "title": "Docling",
    "license": "MIT for code; model licenses are separate",
    "decision": "Optional advanced ingestion and OCR layer.",
    "text": "Useful when PDFs contain complex layouts, tables, or scanned content. The project supports local document processing and offers an MCP server. Its current README requires Python 3.10+ and distinguishes code licensing from individual model licenses. It is heavier than needed for ordinary text CVs and was not installed for this first version.",
    "url": "https://github.com/docling-project/docling",
    "category": "infrastructure"
  }
];
