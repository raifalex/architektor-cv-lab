import { ArrowRight, ArrowUpRight, Check, Clock, Download, MessageCircle } from "lucide-react";
import type { Language } from "@/lib/report-types";

const copy = {
 en: {
  nav: "Personal review", eyebrow: "A SEPARATE, PERSONAL SERVICE",
  title: "More depth. A real conversation.",
  intro: "Alex Raif personally reviews your CV with his own tools, explores your options, and helps you decide what to do next.",
  offer: "Extended CV & career analysis + a 30-minute personal conversation.",
  once: "USD · one-time payment", total: "Total for the analysis and conversation", details: "Explore the personal review",
  included: "What’s included", items: ["An extended review of your CV, strengths, and supporting experience.", "Plausible career directions, important gaps, and priorities for improving your CV.", "A 30-minute personal conversation with Alex to discuss the findings and practical next steps."],
  duration: "30-minute conversation", person: "Personally reviewed by Alex Raif", payment: "One service. One payment. No subscription.",
  stepsTitle: "How to arrange it", steps: ["Send Alex a request on WhatsApp.", "Agree on the time, payment method, and how to share your CV directly with Alex.", "Alex completes the extended analysis; discuss the findings together in your 30-minute conversation."],
  request: "Contact Alex on WhatsApp", note: "Opens WhatsApp with a request you can edit and send. No payment is taken and no appointment is booked on this site.",
  privacy: "Your CV and automatic results are not attached or sent when you open WhatsApp. You choose what to share directly with Alex.",
  automated: "Start with the automatic review", autoText: "The built-in rules review remains available on its own. This personal service is optional and arranged separately.",
  back: "Back to my review", start: "Start an automatic review", export: "Download my current review",
  message: "Hi Alex, I’m interested in the extended CV and career analysis plus a 30-minute personal conversation for a one-time total of $20 USD. Can we arrange the time and payment?"
 },
 he: {
  nav: "ניתוח אישי", eyebrow: "שירות אישי נפרד",
  title: "יותר עומק. שיחה אישית.",
  intro: "אלכס רייף ינתח אישית את קורות החיים שלך בכלים שלו, יבחן איתך כיוונים אפשריים ויעזור לך להחליט על הצעד הבא.",
  offer: "ניתוח מורחב של קורות החיים וכיוון הקריירה + שיחה אישית של 30 דקות.",
  once: "דולר ארה״ב · תשלום חד־פעמי", total: "מחיר כולל לניתוח ולשיחה", details: "לפרטי הניתוח האישי",
  included: "מה כלול בשירות", items: ["ניתוח מורחב של קורות החיים, החוזקות והניסיון שמבסס אותן.", "בחינת כיווני קריירה אפשריים, פערים חשובים וסדר עדיפויות לשיפור קורות החיים.", "שיחה אישית של 30 דקות עם אלכס על הממצאים ועל צעדים מעשיים להמשך."],
  duration: "שיחה אישית של 30 דקות", person: "ניתוח אישי של אלכס רייף", payment: "שירות אחד. תשלום אחד. ללא מנוי.",
  stepsTitle: "איך מתאמים", steps: ["שולחים לאלכס בקשה בוואטסאפ.", "מתאמים ישירות עם אלכס את המועד, אופן התשלום והעברת קורות החיים.", "אלכס מבצע את הניתוח המורחב, ובשיחה של 30 דקות עוברים יחד על הממצאים והצעדים הבאים."],
  request: "פנייה לאלכס בוואטסאפ", note: "ייפתח וואטסאפ עם הודעת בקשה שניתן לערוך ולשלוח. באתר לא מתבצע חיוב ולא נקבע תור.",
  privacy: "קורות החיים ותוצאות הניתוח האוטומטי לא מצורפים ולא נשלחים בפתיחת וואטסאפ. הבחירה מה לשתף עם אלכס היא שלך.",
  automated: "אפשר להתחיל בניתוח האוטומטי", autoText: "הניתוח לפי החוקים המובנים זמין בפני עצמו. השירות האישי הוא אפשרות נוספת ונפרדת, בתיאום ישיר.",
  back: "חזרה לניתוח שלי", start: "התחלת ניתוח אוטומטי", export: "הורדת הניתוח הנוכחי",
  message: "היי אלכס, אני מעוניין/ת בניתוח מורחב של קורות החיים וכיוון הקריירה, כולל שיחה אישית של 30 דקות, במחיר כולל של 20 דולר ארה״ב בתשלום חד־פעמי. אפשר לתאם מועד ואופן תשלום?"
 },
 uk: {
  nav: "Особистий розбір", eyebrow: "ОКРЕМА ПЕРСОНАЛЬНА ПОСЛУГА",
  title: "Глибший аналіз. Особиста розмова.",
  intro: "Алекс Райф особисто проаналізує ваше резюме власними інструментами, розгляне можливі напрями та допоможе визначити наступний крок.",
  offer: "Розширений аналіз резюме та кар’єрних напрямів + особиста розмова на 30 хвилин.",
  once: "USD · одноразова оплата", total: "Загальна вартість аналізу та розмови", details: "Детальніше про особистий розбір",
  included: "Що входить", items: ["Розширений аналіз резюме, сильних сторін і досвіду, що їх підтверджує.", "Можливі кар’єрні напрями, важливі прогалини та пріоритети покращення резюме.", "Особиста розмова з Алексом на 30 хвилин про висновки та практичні наступні кроки."],
  duration: "Розмова на 30 хвилин", person: "Особистий аналіз від Алекса Райфа", payment: "Одна послуга. Одна оплата. Без підписки.",
  stepsTitle: "Як домовитися", steps: ["Напишіть Алексу у WhatsApp.", "Узгодьте час, спосіб оплати та передачі резюме безпосередньо з Алексом.", "Алекс виконає розширений аналіз; обговоріть висновки під час 30-хвилинної розмови."],
  request: "Написати Алексу у WhatsApp", note: "Відкриється WhatsApp із запитом, який можна змінити та надіслати. На цьому сайті оплата не стягується і зустріч не бронюється.",
  privacy: "Резюме й автоматичні результати не додаються та не надсилаються під час відкриття WhatsApp. Ви самі обираєте, чим поділитися з Алексом.",
  automated: "Почніть з автоматичного аналізу", autoText: "Аналіз за вбудованими правилами доступний окремо. Особиста послуга необов’язкова та узгоджується безпосередньо.",
  back: "До мого аналізу", start: "Почати автоматичний аналіз", export: "Завантажити поточний аналіз",
  message: "Привіт, Алекс! Мене цікавить розширений аналіз резюме та кар’єрних напрямів з особистою розмовою на 30 хвилин за одноразову загальну оплату 20 доларів США. Можемо узгодити час та оплату?"
 },
 ru: {
  nav: "Личный разбор", eyebrow: "ОТДЕЛЬНАЯ ПЕРСОНАЛЬНАЯ УСЛУГА",
  title: "Глубокий анализ. Личный разговор.",
  intro: "Алекс Райф лично проанализирует ваше резюме своими инструментами, рассмотрит возможные направления и поможет выбрать следующий шаг.",
  offer: "Расширенный анализ резюме и карьерных направлений + личный разговор на 30 минут.",
  once: "USD · разовая оплата", total: "Общая стоимость анализа и разговора", details: "Подробнее о личном разборе",
  included: "Что входит", items: ["Расширенный анализ резюме, сильных сторон и подтверждающего их опыта.", "Возможные карьерные направления, важные пробелы и приоритеты улучшения резюме.", "Личный разговор с Алексом на 30 минут о выводах и практических следующих шагах."],
  duration: "Разговор на 30 минут", person: "Личный анализ от Алекса Райфа", payment: "Одна услуга. Одна оплата. Без подписки.",
  stepsTitle: "Как договориться", steps: ["Напишите Алексу в WhatsApp.", "Согласуйте время, способ оплаты и передачи резюме напрямую с Алексом.", "Алекс выполнит расширенный анализ; обсудите выводы во время 30-минутного разговора."],
  request: "Написать Алексу в WhatsApp", note: "Откроется WhatsApp с запросом, который можно изменить и отправить. На этом сайте оплата не списывается и встреча не бронируется.",
  privacy: "Резюме и автоматические результаты не прикладываются и не отправляются при открытии WhatsApp. Вы сами выбираете, чем поделиться с Алексом.",
  automated: "Начните с автоматического анализа", autoText: "Анализ по встроенным правилам доступен отдельно. Личная услуга необязательна и согласуется напрямую.",
  back: "К моему анализу", start: "Начать автоматический анализ", export: "Скачать текущий анализ",
  message: "Привет, Алекс! Меня интересует расширенный анализ резюме и карьерных направлений с личным разговором на 30 минут за разовую общую оплату 20 долларов США. Можем согласовать время и оплату?"
 }
};

export const personalReviewLabel = (language: Language) => copy[language].nav;

export function PersonalOffer({ language, onOpen }: { language: Language; onOpen: () => void }) {
 const c = copy[language];
 return <section className="personal-offer" lang={language} dir={language === "he" ? "rtl" : "ltr"}>
  <div className="personal-offer-icon"><MessageCircle size={25}/></div>
  <div className="personal-offer-copy"><span className="kicker">{c.eyebrow}</span><h2>{c.title}</h2><p>{c.offer}</p></div>
  <div className="personal-offer-action"><div><b dir="ltr">$20</b><span>{c.once}</span></div><button className="text-button" onClick={onOpen}>{c.details}<ArrowUpRight size={16}/></button></div>
 </section>;
}

export function PersonalReview({ language, hasReport, onBack, onExport }: { language: Language; hasReport: boolean; onBack: () => void; onExport: () => void }) {
 const c = copy[language];
 // Only a generic service inquiry is shared. Candidate data never enters this URL.
 const contact = `https://wa.me/972546608056?text=${encodeURIComponent(c.message)}`;
 return <div className="personal-review" lang={language} dir={language === "he" ? "rtl" : "ltr"}>
  <div className="view-heading personal-heading"><div><span className="kicker">{c.eyebrow}</span><h1>{c.title}</h1><p>{c.intro}</p></div></div>
  <div className="personal-layout">
   <div className="personal-details">
    <section className="panel personal-included"><span className="kicker">ARCHITEKTOR · ALEX RAIF</span><h2>{c.included}</h2><ul>{c.items.map(item => <li key={item}><Check size={19}/><span>{item}</span></li>)}</ul></section>
    <section className="panel personal-process"><h2>{c.stepsTitle}</h2><ol>{c.steps.map((step, i) => <li key={step}><span className="personal-step" aria-hidden="true">0{i + 1}</span><p>{step}</p></li>)}</ol></section>
   </div>
   <aside className="personal-price-card"><span className="kicker">{c.person}</span><div className="personal-price" dir="ltr">$20 <span>USD</span></div><p className="personal-total">{c.total}</p><p className="personal-once">{c.payment}</p><div className="personal-duration"><Clock size={18}/>{c.duration}</div><a className="btn primary full" href={contact} target="_blank" rel="noopener noreferrer">{c.request}<ArrowUpRight size={18}/></a><p className="personal-contact-note">{c.note}</p></aside>
  </div>
  <div className="personal-privacy"><MessageCircle size={18}/><p>{c.privacy}</p></div>
  <section className="personal-auto"><div><h2>{c.automated}</h2><p>{c.autoText}</p></div><div className="personal-auto-actions"><button className="btn secondary" onClick={onBack}>{hasReport ? c.back : c.start}<ArrowRight size={16}/></button>{hasReport && <button className="text-button" onClick={onExport}><Download size={16}/>{c.export}</button>}</div></section>
 </div>;
}
