# ARCHITEKTOR CV & Career Studio

A static, browser-only career studio for GitHub Pages. No API key, server, database, or paid model is needed.

## Features

- Upload a readable PDF, DOCX, TXT or Markdown CV; extraction stays in the browser.
- Discover plausible IT career directions using explicit, inspectable rules.
- Tailor to a specific vacancy as a secondary mode.
- English, Hebrew, Ukrainian and Russian reports; Hebrew personal-service content supports RTL.
- Optional separate personal analysis by Alex Raif plus one 30-minute conversation: **$20 USD total, one-time**.
- Personal-service inquiries open WhatsApp with generic text only. Payment, scheduling and sharing a CV are coordinated directly; this site does not process payments or book appointments.

## Develop and build

Use Node.js 22.13+ and the pnpm version in `package.json`.

```sh
pnpm install --frozen-lockfile --ignore-scripts
pnpm test
pnpm build
pnpm preview
```

The `dist/` folder is the complete production site. Relative asset paths allow it to run under a GitHub project path. The PDF worker is bundled locally. No external font or model service is required.

## Publish on GitHub Pages

Create a repository, upload this source including `.github/workflows/pages.yml`, and select **Settings → Pages → Source → GitHub Actions**. A push to `main` runs tests, builds the static site and deploys it.

Alternatively, publish the already-built contents of `dist/` from a branch root with the included `.nojekyll` file.

## Data and migration

CVs are not automatically uploaded or saved. “Save in browser” uses localStorage on the current origin. Saved cases on the previous hostname do not move automatically: export them there before leaving. Reports can be downloaded as Markdown or JSON.

Only application code, synthetic tests and license notices belong in this repository. Do not commit real CVs, exported cases, keys or `.env` files.

The rules rank evidence, not people. Their weights are editorial and are not validated psychological scores, hiring predictions or employer ATS scores. See `documentation/rulebook.md` for the method and limits.
